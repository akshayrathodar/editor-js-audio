//link to page kc
export default class LinktoPage {

   constructor({data, api, config}){
     this.api = api;
     this.config = config || {};
     this.data = {
       linktopageslug: data.linktopageslug || '',
       linkpagename: data.linkpagename || '',
       pageicon: data.pageicon || '',
       icontype: data.icontype || '',
       linkpageid: data.linkpageid || '',
     };     
     this.currentclick = '';
     this.modelid = '';
  }

  static get toolbox() {
    return {
      title: 'Link to Page',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24"><path d="M11 9c1.361-5.928 8-7 8-7v-2l4 3.982-4 4.018v-2s-5.102-.104-8 3zm5 1h-10v1h10v-1zm3 .835v2.708c0 4.107-6 2.457-6 2.457s1.518 6-2.638 6h-7.362v-20h10.741c1.176-.758 2.35-1.242 3.259-1.541v-.459h-16v24h10.189c3.163 0 9.811-7.223 9.811-9.614v-5.561l-2 2.01zm-13 3.165h10v-1h-10v1zm3.609-7h-3.609v1h3.266l.343-1z"/></svg>'
    };
  }




  render(){
    var modelid = Math.random().toString(36).substr(2, 9);
  this.modelId = modelid;    
    var maindivbox = this._make('div',['modal-dialog-data'],{'role':'document',"id":modelid,"data-id":"rootmodel",'data-modelid':modelid});

    var currentws = localStorage.getItem("active_workspace");
    var currentuser = localStorage.getItem('auth_token');
    if(this.data.linkpageid !='' && this.data.linkpageid != 'undefined' ){
      
      let formdata = new FormData();
     formdata.append("request", 'pageid');
     formdata.append("auth_token", currentuser);
     formdata.append("workspace_id", currentws);
     formdata.append("currentpageid",this.data.linkpageid);
      $.ajax({
            url: API_END_POINT + "page.getpages", 
             type: "POST",
            data: formdata,
            processData: false,
            contentType: false,
            success: function(result)
            {
              var s = document.createElement("ins");              
              s.setAttribute('dataid',result.data.pagedata.id);
              s.setAttribute('class','pagelink-url');
              
              //var pageapp      = this._make('ins','pagelink-url',{'data-id':result.data.pagedata.id,'id':this.data.linktopageslug,'data-name':this.data.linkpagename,'data-img':this.data.pageicon,'data-icontype':this.data.icontype});
           //maindivbox.appendChild(pageapp); 
           maindivbox.appendChild(s); 

              var pageurl = '/ws/'+result.data.pagedata.domain_name+'/'+result.data.pagedata.page_url;
              if(result.data.pagedata.icontype == 'image'){
                var pageimage = '<img src="'+result.data.pagedata.page_icon+'" height="20" width="20" >';
              }else if (result.data.pagedata.icontype == 'emoji') {
                var pageimage = result.data.pagedata.page_icon;
              }else{
                var pageimage = '<i class="fa fa-file-text-o "></i>';
              }
              //s.innerHTML = pageimage+'<a data-url="'+pageurl+'" href="'+pageurl+'" _ngcontent-ujs-c3="" class="pushpagetourl"><i class="fa fa-arrow-up"></i> '+result.data.pagedata.page_name+'</a> ';
              s.innerHTML = pageimage+'<a _1ngcontent-ujs-c3="" id="ab" data-link="'+pageurl+'" class="pushpagetourl1"><i class="fa fa-arrow-up"></i> '+result.data.pagedata.page_name+'</a> ';
            }
        })
      //var parsedUrl = new URL(window.location.href);      
      //var baseUrl = parsedUrl.origin;
      /*var pageicon = '';
      if(this.data.icontype =='img'){
        pageicon = '<img src="'+this.data.pageicon+'" height ="20" width="20" >';
      }else if (this.data.icontype == 'emoji') {
        pageicon = this.data.pageicon;
      }else{
        pageicon = '<i class="fa fa-file-text-o "></i>';
      }*/
      //pageapp.innerHTML= pageicon+'<a href="'+this.data.linktopageslug+'" _ngcontent-ujs-c3="">'+this.data.linkpagename+'</a> ';
      return maindivbox;
    }

    var s = document.createElement("div");
    var wrapper = this._make('div',['cdx-button','linktopagebox'],{});

    var secondcenter   = this._make('div','',{'style':'text-align:left;padding:5px;'});
    secondcenter.innerHTML = 'Select a page';
 
    wrapper.appendChild(secondcenter);    

    
    maindivbox.appendChild(wrapper);
    var modalcontent   = this._make('div','modal-content',null);
    maindivbox.appendChild(modalcontent);
    var modalbody      = this._make('div','modal-body',null);
    modalcontent.appendChild(modalbody);

    var contentdiv      = this._make('div','page-list',null);
    modalbody.appendChild(contentdiv);

    

     let formdata = new FormData();
     formdata.append("request", 'allpages');
     formdata.append("auth_token", currentuser);
     formdata.append("workspace_id", currentws);
    $.ajax({
            url: API_END_POINT + "page.getpages", 
            type: "POST",
            data: formdata,
            processData: false,
            contentType: false,
            success: function(result)
            {
              let pagedata = result.data.pagedata;
              let publicpagedata = result.data.publicpagedata;
          
              var resultdata='';              
              pagedata.forEach( function(element, i) {                
                var classname ='oddbg';                
                var pageicon = '';
                var icontype = '';
                if(element.icontype == 'null'){
                   pageicon = '<i class="fa fa-file-text-o "></i>';
                   icontype = 'itag';
                }else if (element.icontype == 'image') {
                   pageicon = '<img src="'+element.page_icon+'" height = "20" width = "20" >';
                   icontype = 'img';
                }else{
                  icontype = 'emoji';
                   pageicon = element.page_icon;
                }
                resultdata +='<div class="'+classname+' pageselect">'+pageicon+'&nbsp;<a dataid="'+element.id+'" data-icontype="'+icontype+'" data-img="'+element.page_icon+'" href="javascript:void(0)" id="ws/'+element.domain_name+'/'+element.page_url+'">'+element.page_name+'</a></div>';
              });
              var publicresult = '';
              publicpagedata.forEach( function(element, i) {                
                var classname ='oddbg';                
                var pageicon = '';
                var icontype = '';
                if(element.icontype == 'null'){
                   pageicon = '<i class="fa fa-file-text-o "></i>';
                   icontype = 'itag';
                }else if (element.icontype == 'image') {
                   pageicon = '<img src="'+element.page_icon+'" height = "20" width = "20" >';
                   icontype = 'img';
                }else{
                  icontype = 'emoji';
                   pageicon = element.page_icon;
                }
                publicresult += '<div class="'+classname+' pageselect">'+pageicon+'&nbsp;<a dataid="'+element.id+'" data-icontype="'+icontype+'" data-img="'+element.page_icon+'" href="javascript:void(0)" id="ws/'+element.domain_name+'/'+element.page_url+'">'+element.page_name+'</a></div>';
              });              
              var finalpages = resultdata.concat(publicresult)
              $('.page-list').html(finalpages);
            }
        });
    var pageapp      = this._make('ins','pagelink-url',{'id':'','data-img':'','dataid':''});
      maindivbox.appendChild(pageapp);

    $(document).on('click','.page-list .pageselect a',(event)=>{
      //var currentpageurl = $(this).attr('id');      
      var currentid = ($(event.target).attr('dataid'));
      var currentpageurl = ($(event.target).attr('id'));
      var currentpageicon = ($(event.target).attr('data-img'));
      var pageicontype    = ($(event.target).attr('data-icontype'));
      var pageicon = '';
      if(pageicontype =='img'){
      pageicon = '<img src="'+currentpageicon+'" height = "20" width="20">';
      }else if (pageicontype =='itag') {
        pageicon = '<i class="fa fa-file-text-o "></i>';
      }else {
        pageicon = currentpageicon;
      }

      var currentpagename = $(event.target).prop('text');
      $(event.target).parents('.modal-content').addClass('hide');
      $('.linktopagebox').addClass('hide');
      
      //$(event.target).parents('.modal-dialog-data').children('.pagelink-url').html(pageicon+'&nbsp;<a href="'+currentpageurl+'" _ngcontent-ujs-c3=""><i class="fa fa-arrow-up"></i> '+currentpagename+'</a> ');
      $(event.target).parents('.modal-dialog-data').children('.pagelink-url').html(pageicon+'&nbsp;<a data-link="'+currentpageurl+'" data-url="'+currentpageurl+'" class="pushpagetourl1" _ngcontent-ujs-c3=""><i class="fa fa-arrow-up"></i> '+currentpagename+'</a> ');

      //$(event.target).parents('.modal-dialog-data').children('.pagelink-url').attr('id',currentpageurl);
      $(event.target).parents('.modal-dialog-data').children('.pagelink-url').attr('dataid',currentid);
      /*$(event.target).parents('.modal-dialog-data').children('.pagelink-url').attr('data-name',currentpagename);
      $(event.target).parents('.modal-dialog-data').children('.pagelink-url').attr('data-img',currentpageicon);
      $(event.target).parents('.modal-dialog-data').children('.pagelink-url').attr('data-icontype',pageicontype);*/
      //this.linkpage =  '/ws/'+currentpageurl;
      //this.pagename = currentpagename;
    })

    return maindivbox;
  }

  save(blockContent){
    var pageid = $(blockContent).find('ins').attr('dataid');
    /*var pageurl = $(blockContent).find('ins').attr('id');
    var pagename = $(blockContent).find('ins').attr('data-name');
    var pageicon = $(blockContent).find('ins').attr('data-img');
    var pageicontype = $(blockContent).find('ins').attr('data-icontype');*/
    if(pageid !='' && pageid != undefined ){
    //return {"linkpageid":pageid,"linktopageslug": pageurl,'linkpagename':pagename,'pageicon':pageicon,'icontype':pageicontype};
      return {"linkpageid":pageid};
    }
  }

  _make(tagName, classNames = null, attributes = {}) {
      const el = document.createElement(tagName);

      if (Array.isArray(classNames)) {
        el.classList.add(...classNames);
      } else if (classNames) {
        el.classList.add(classNames);
      }
    
      for (const attrName in attributes) {
        el.setAttribute(attrName,attributes[attrName]);
  //      el[attrName] = attributes[attrName];
      }

      return el;
  }
}