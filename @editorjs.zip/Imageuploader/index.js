
export default class ImageuploadAr {

   constructor({data, api, config}){
   this.api = api;
   this.config = config || {};
   this.data = data;
   this.currentImg = '';
   this.modelId = '';
   this.ID = () => {
        return '_' + Math.random().toString(36).substr(2, 9);
     };

    // ... this.data
    // ... this.wrapper
    // ... this.settings
  }
  static get toolbox() {
    return {
      title: 'Image Upload',
      icon: '<svg xmlns="http://www.w3.org/2000/svg" width="17" height="17" viewBox="0 0 24 24"><path d="M19.5 12c-2.483 0-4.5 2.015-4.5 4.5s2.017 4.5 4.5 4.5 4.5-2.015 4.5-4.5-2.017-4.5-4.5-4.5zm2.5 5h-2v2h-1v-2h-2v-1h2v-2h1v2h2v1zm-18 0l4-5.96 2.48 1.96 2.52-4 1.853 2.964c-1.271 1.303-1.977 3.089-1.827 5.036h-9.026zm10.82 4h-14.82v-18h22v7.501c-.623-.261-1.297-.422-2-.476v-5.025h-18v14h11.502c.312.749.765 1.424 1.318 2zm-9.32-11c-.828 0-1.5-.671-1.5-1.5 0-.828.672-1.5 1.5-1.5s1.5.672 1.5 1.5c0 .829-.672 1.5-1.5 1.5z"/></svg>'
    };
  }


  render(){
    // main model : data-id:rootmodel
    // file input : name : editorfileupload , id : editorfileupload
    // link textbox : id : editorlinkpast
    // button link : id : editorlinkbtn
     // img name:image , id : editorimg

     

     let uploadtabid = this.ID();
     let imagetabid  = this.ID();

     if(this.data.imageurl != '' && this.data.imageurl != undefined) {
       var modelid = Math.random().toString(36).substr(2, 9);
       $('#hiddenimg').val(this.data.imageurl);
       let imgurl = this.data.imageurl;
       var wrap = document.createElement('div');
       wrap.setAttribute('data-modelid',modelid);
       var imagetag = this._make('img',null,{"name":"editorimg","id":Math.random().toString(36).substr(2, 9),"src":imgurl});
       wrap.appendChild(imagetag);
       this.modelId = modelid;
       //wrap.appendChild(divboth); 
     } else {
        var wrap = this._make('div','cdx-block',{});
        var img = this._make('img',null,{"name":"editorimg","id":"editorimg"});
        var modelid = Math.random().toString(36).substr(2, 9);

        let uploadimgId = this.ID();
        let pastelinkId = this.ID();
        wrap.innerHTML = '<div class="modal-dialog" role="document" id="mainmodel" data-id="rootmodel" data-modelid="'+modelid+'"><center><h1 id="edload" class="hide"> Loading..</h1></center><div class="modal-content"><div class="modal-body"><div class="gen-tabs"><ul class="nav nav-tabs" role="tablist"><li class="active" role="presentation"><a href="#uploadimg'+uploadimgId+'" aria-controls="uploadimg" role="tab" data-toggle="tab" aria-expanded="true">Upload an Image</a></li><li role="presentation" class=""><a href="#imglinkeditor'+pastelinkId+'" aria-controls="imglinkeditor" role="tab" data-toggle="tab" aria-expanded="false">Image Link</a></li></ul><div class="tab-content cf"><div role="tabpanel" id="uploadimg'+uploadimgId+'" class="tab-pane active"><div class="choose-upload text-center"><div class="main-btn sm-btn"> <input type="file" name="editorfileupload" id="editorfileupload"> Upload Image</div> <small id="editorerrormsg" style="color:red;"></small></div></div><div role="tabpanel" class="tab-pane" id="imglinkeditor'+pastelinkId+'"><div class="choose-upload text-center"><div class="form-group cf"> <input type="text" class="is-form-control" name="editorlinkpast" id="editorlinkpast" placeholder="Paste an Image Link.."> <button type="submit" class="main-btn sm-btn" id="editorlinkbtn"> Submit an Link </button> <small>Works with any image from the web</small></div></div></div></div></div></div></div></div>';
        this.modelId = modelid;
        wrap.appendChild(img); 
       // setInterval( () =>{ this.save(); }, 1000);   
     }


     // change
     $(document).on('change','#editorfileupload', (event) => {
    //   ip.placeholder = event.target.value;
        
         let formdata = new FormData();
         let file = event.target.files[0];


         const  fileType = file['type'];
       const validImageTypes = ['image/gif', 'image/jpeg', 'image/png'];
       if (validImageTypes.includes(fileType)) {
        
            
          formdata.append("file", file);
          formdata.append("psize",$('#psize').val());
          formdata.append('user',$('#user_identification').val());
          formdata.append('wp_identification',$('#wp_identification').val());
          formdata.append('pg_identification',$('#pg_identification').val());

          $(event.target).parents('.modal-content').addClass('hide');
          $('#edload').removeClass('hide');

          $.ajax({
            url: API_END_POINT + "editor.attach", 
            type: "POST",
            data: formdata,
            processData: false,
            contentType: false,
            success: function(result)
            {
              if(result.file == "largefile") { 
                
                $('#editorerrormsg').html('Please Upload Small Image Or Upgrade Your Plan');
              } else {

              var s = document.createElement("IMG");
              s.src = result.body.file.url;
              s.id  = '_' + Math.random().toString(36).substr(2, 9);
              
              s.onerror = function(){
                alert("Invalid Image Url");

                return false;
              }
              s.onload = function(){
                this.currentImg = result.body.file.url;
              //  $(event.target).parents('.modal-dialog').css("background-image", "");
                $(event.target).parents('.modal-dialog').html(s);
                $('#hiddenimg').val(result.body.file.url);
                this.save;
                console.log("save called");  
                // $('#mainmodel').html(s);
              //  console.log($(event.target).parent('#mainmodel'));
    //            $('[data-id="rootmodel"]').remove();
              }                  
              }
              
            }
          });
          // change over

       } else {
           alert("Please Select a Proper Image");
       }      

  });


  $(document).on('click','#editorlinkbtn',(event)=>{
      let link = $('#editorlinkpast').val();
      //checkImage(link);
     
      var s = document.createElement("IMG");
      s.src = link;
    s.id  = this.ID();
    
      s.onerror = function(){
            alert("Invalid Image Url");
            return false;
      }
      s.onload = function(){
        $(event.target).parents('.modal-dialog').html(s);
            // $('#mainmodel').html(s);
          //  console.log($(event.target).parent('#mainmodel'));
//            $('[data-id="rootmodel"]').remove();
      }    
});    

    return wrap;
  }


  
  save(blockContent){ 

    this.currentImg = $('[data-modelid="'+this.modelId+'"]').find('img').attr('src');
    
    return {
      "imageurl": this.currentImg,
    };  
   
//    return {"atag":$('#elink').attr('href')};
  }

  removed() {
    //console.log($('#hiddenimg').val());
    //console.log($('[data-modelid="'+this.modelId+'"]').html());
    let url = $('#hiddenimg').val();
    var arr = url.split("/");
    var result = arr[0] + "//" + arr[2];
    
    if(result.includes(this.config.domain))
    {
        var index = url.lastIndexOf("/") + 1;
        var filename = url.substr(index);
        let fd = new FormData();
        fd.append("img_name",filename);
        fd.append("user",$('#user_identification').val());
        fd.append('wp_identification',$('#wp_identification').val());
        fd.append('pg_identification',$('#pg_identification').val());

         $.ajax({
          url: API_END_POINT+"editor.deattachimg", 
          type: "POST",
          data: fd,
          processData: false,
          contentType: false,
          success: function(result)
          {
            console.log(result);
          }
        })

    } 
    // var index = link.lastIndexOf("/") + 1;
    // var filename = link.substr(index);

    // if(link != undefined && link != '') {
    //   console.log(filename);
    // }
  }

  //
  // renderSettings(){
  //   const settings = [
  //     {
  //       name: 'Delete',
  //       icon: `<svg xmlns="http://www.w3.org/2000/svg" width="18" height="18" viewBox="0 0 24 24"><path d="M12 0c-4.992 0-10 1.242-10 3.144 0 .406 3.556 18.488 3.633 18.887 1.135 1.313 3.735 1.969 6.334 1.969 2.601 0 5.199-.656 6.335-1.969.081-.404 3.698-18.468 3.698-18.882 0-2.473-7.338-3.149-10-3.149zm-3.403 13.581l-.492-.323 1.824-.008.78 1.667-.506-.32c-.723 1.146-1.027 1.764-.796 2.481-1.823-1.798-1.622-2.182-.81-3.497zm.622-1.304l.781-1.418c.195-.38 1.251-.075 1.688.899l-.797 1.445-1.672-.926zm2.673 5.175h-1.729c-.427.013-.672-1.061-.031-1.915h1.761v1.915zm.058-4.886l.524-.289c-.652-1.188-1.044-1.753-1.781-1.898 2.451-.729 2.593-.41 3.445.981l.521-.275-.79 1.654-1.919-.173zm3.059.005l.911 1.474c.236.355-.546 1.129-1.607 1.035l-.928-1.501 1.624-1.008zm-1.549 4.846l-.004.583-1.028-1.616 1.054-1.47-.006.6c1.354.011 2.037-.055 2.524-.63-.565 2.5-.942 2.533-2.54 2.533zm-1.409-12.27c-4.211 0-7.625-.746-7.625-1.667s3.414-1.667 7.625-1.667 7.624.746 7.624 1.667-3.413 1.667-7.624 1.667z"/></svg>`
  //     },

  //   ];
  //   const wrapper = document.createElement('div');

  //   settings.forEach( tune => {
  //     let button = document.createElement('div');

  //     button.classList.add('cdx-settings-button');
  //     button.innerHTML = tune.icon;
  //     wrapper.appendChild(button);

  //     button.addEventListener('click', () => {
        
  //       if(tune.name == 'Delete') {
  //          this.removed();
  //       }
  //     });

  //   });

  //   return wrapper;
  // }





   
  _make(tagName, classNames = null, attributes = {}) {
    const el = document.createElement(tagName);

    if (Array.isArray(classNames)) {
      el.classList.add(...classNames);
    } else if (classNames) {
      el.classList.add(classNames);
    }

    for (const attrName in attributes) {
      el[attrName] = attributes[attrName];
    }

    return el;
  }
}

